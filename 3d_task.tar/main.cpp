//#include <QtGui/QApplication>
#include "mainwindow.h"

///static double *coefss = 0;

void delete_array (unsigned int *a)
{
  if (a)
    delete [] a;
  a = 0;
}

void delete_array (double *a)
{
  if (a)
    delete a;
  a = 0;
}

void *main_thread (void *arg)
{
  struct args *ar = (struct args *)arg;
  static double *a = 0, *rhs = 0, *c = 0, *u = 0, *v = 0, *r = 0;
  static unsigned int *rnz = 0;
  int n = ar->n, len;
  int non_zeros = 14 * n * n + 6 * n + 1;
  //double res3;

  len = 2 * n * (n + 1) + 1;
  if (ar->thread_num == 0)
    {
      delete_array(a);
      delete_array(rhs);
      delete_array(rnz);
      if (!(a   = new double [non_zeros + 1]) ||
          !(rnz = new unsigned int [non_zeros + 1]) ||
          !(rhs = new double [len])           ||
          !(c   = new double [len])           ||
          !(u   = new double [len])           ||
          !(r   = new double [len])           ||
          !(v   = new double [len]))
        {
          delete_array(a);
          delete_array(rhs);
          delete_array(rnz);
          delete_array(c);
          delete_array(u);
          delete_array(r);
          delete_array(v);
        }
      else
        memset (c, 0, len * sizeof (double));
    }
  reduce_sum <int>(ar->total_threads);
  init_sparse_matrix (a, rnz, r, ar->x, ar->y, n, ar->thread_num, ar->total_threads);
  init_rhs_for_test(rhs, len, r, a, rnz, ar->thread_num, ar->total_threads);

  solve (a, rnz, len, rhs, c, 1e-7, 1000, r, u, v, ar->thread_num, ar->total_threads);
  reduce_sum <int>(ar->total_threads);
  if (c || ar->thread_num == 0)
    memcpy (coefss, c, sizeof (double) * len);

  if (ar->thread_num == ar->total_threads - 1)
    {
      printf ("number of equations: %d\n", len);

      delete_array(a);
      delete_array(rhs);
      delete_array(rnz);
      delete_array(c);
      delete_array(u);
      delete_array(r);
      delete_array(v);
    }

  return 0;
}

int main(int argc, char *argv[])
{
//  double x[4] = {0,0,1,1};
//  double y[4] = {0,1,1,0};
//  int n = 3;
//  printf ("n %d\n", n);
//  int N = 2 * n * (n + 1) + 1;

//  int non_zeros = 14 * n * n + 6 * n + 1;

//  double *a = new double [non_zeros + 1];
//  if (!a)
//    return 1;
//  unsigned int *jnz = new unsigned int [non_zeros + 1];
//  if (!jnz)
//    {
//      delete [] a;
//      return 1;
//    }
//  double *f   = new double [N];
//  double *rhs = new double [N];

//  init_sparse_matrix (a, jnz, f, x, y, n, 0, 1);
//  //init_sparse_matrix (a, jnz, f, x, y, n, 1, 2);
//  print_sparse_matrix (a, jnz, N ,non_zeros);
//  init_rhs_for_test(rhs, N, f, a, jnz, 0, 1);
//  print_vector (f, N);
//  print_vector (rhs, N);

//  delete [] a;
//  delete []jnz;
//  delete [] f;
//  delete [] rhs;
//  return 0;
  QApplication app(argc, argv);
  MainWindow *window = new MainWindow;

  if (window->parce_comand_line (argc, argv))
    {
      printf ("usage: %s <x1> <y1> <x2> <y2> <n> <total_threads>\n", argv[0]);
      delete window;
      return 1;
    }
  window->setGeometry (100, 100, 950, 950);

  window->recount ();
  window->show ();
  app.exec ();

  delete window;
  return 0;
}
