#include "mainwindow.h"
#include "GL/glu.h"

double ff (double x, double y)
{
  return x + y;
}

MainWindow::MainWindow(QWidget* parent) : QGLWidget(parent)
{
  setFormat(QGLFormat(QGL::DoubleBuffer));
  glDepthFunc(GL_LEQUAL);
  w = 800, h = 800;
  xRot = zRot = 0;
  is_pressed = false;
  scale = 1;
  ar = 0;
  coefs = 0;
  draw_type = 0;
}

MainWindow::~MainWindow()
{
  if (coefs) delete [] coefs;
  if (ar) delete [] ar;
}

int MainWindow::parce_comand_line (int argc, char *argv[])
{
  double x1, y1, x2, y2;
  if (argc != 9 ||
      !(x1 = atof (argv[1])) ||
      !(y1 = atof (argv[2])) ||
      !(x2 = atof (argv[3])) ||
      !(y2 = atof (argv[4])) ||
      !( n = atoi (argv[6])) ||
      !(total_threads = atoi (argv[7])))
    return 1;

  x[0] = x1;
  y[0] = y1;

  x[1] = x2;
  y[1] = y2;

  hx = x2 - x1;
  hy = y1 - y2;

  N = 2 * n * (n + 1) + 1;

  x[2] = x[0] + 2 * hx;
  y[2] = y[0];

  x[3] = x[1];
  y[3] = y[1] + 2 * hy;

  hx /= n;
  hy /= n;

  ar = new struct args [total_threads];

  return 0;
}


void MainWindow::recount ()
{
  int i;
  pthread_t tid;

  if (coefss) delete [] coefss;
  if (!(coefss = new double [N]))
    return;

  for (i = 0; i < total_threads; i++)
    {
      ar[i].thread_num = i;
      ar[i].total_threads = total_threads;
      ar[i].hx = hx;
      ar[i].hy = hy;
      ar[i].n = n;
      ar[i].x = x;
      ar[i].y = y;
    }

  if (fabs (hx) < 1e-8  && fabs (hy) < 1e-8)
    {
      printf ("too small interpolation\n");
      return;
    }

  for (i = 1; i < total_threads; i++)
    pthread_create (&tid, 0, main_thread, ar + i);
  main_thread (ar + 0);

  coefs = coefss;
}

void MainWindow::paintGL()
{
  char buf[250];
  QFont font ("Arial", 12, QFont::Bold, false);

  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  gluLookAt (0, 5, 30, 0, 0, 0, 0, 1, 0);
  glRotated (xRot, 1, 0, 0);
  glRotated (zRot, 0, 0, 1);
  glScaled (scale, scale, scale);

  draw_type = 1; /// !!!!!!!!!!!!!!!!!!

  drawAxis ();
  switch (draw_type)
    {
//    case 0:
//      drawInterpolation ();
//      qglColor(Qt::black);
//      renderText (10, 15, QString ("interpolation plot (space to change)"), font);
//      break;
    case 1:
      drawFunction ();
      drawInterpolation ();
      qglColor(Qt::black);
      renderText (10, 15, QString ("interpolation and function plots (space to change)"), font);
      break;
//    case 2:
//      drawThreshold ();
//      qglColor(Qt::black);
//      renderText (10, 15, QString ("residual plot (space to change)"), font);
//      break;
    }

  sprintf (buf, "max absolute value: %.3e, hx = %.2e, hy = %.2e, n = %d (+/- to change)", zmax, hx, hy, n);
  setWindowTitle (QString (buf));
  glFlush ();
  swapBuffers ();
}

void MainWindow::mouseMoveEvent(QMouseEvent *me)
{
  if (is_pressed)
    {
      xRot += 180 * (GLfloat) (me->y () - mouse_position.y ()) / h;
      zRot += 180 * (GLfloat) (me->x () - mouse_position.x ()) / w;
      if (fabs (xRot) < 1e-14)
        xRot = 0;
      if (fabs (zRot) < 1e-14)
        zRot = 0;
      updateGL ();
    }
  mouse_position = me->pos ();
}

void MainWindow::mousePressEvent(QMouseEvent *me)
{
  if(me->button () == Qt::LeftButton)
    {
      is_pressed = true;
      mouse_position = me->pos ();
      updateGL ();
    }
}

void MainWindow::mouseReleaseEvent(QMouseEvent */*me*/)
{
  is_pressed = false;
  updateGL ();
}

void MainWindow::wheelEvent (QWheelEvent *we)
{
  if (we->delta () > 0)
    scale *= 1.1;
  else if (we->delta () < 0)
    scale /= 1.1;
  updateGL ();
}

void MainWindow::resizeGL(int nWidth, int nHeight)
{
  glViewport(0, 0, w = nWidth, h = nHeight);

  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluPerspective(60, (double)w / h, 1, 500);

  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  gluLookAt(0, 0, 30, 0, 0, 0, 0, 1, 0);
}

void MainWindow::drawAxis ()
{
  glBegin (GL_LINES);
  glColor3d (1, 0, 0);
  glVertex4d (0, 0, 0, 1);
  glVertex4d (1, 0, 0, 0);

  glColor3d (0, 1, 0);
  glVertex4d (0, 0, 0, 1);
  glVertex4d (0, 1, 0, 0);

  glColor3d (0, 0, 1);
  glVertex4d (0, 0, 0, 1);
  glVertex4d (0, 0, 1, 0);
  glEnd ();
}

void MainWindow::keyPressEvent(QKeyEvent *ke)
{
  switch (ke->key ())
    {
    case Qt::Key_Escape:
      close ();
      return;
    case Qt::Key_Plus:
      n = 2 * n;
      hx /= 2;
      hy /= 2;
      is_pressed = false;
      recount ();
      break;
    case Qt::Key_Minus:
      if (n <= 4)
        break;
      n = n / 2;
      hx *= 2;
      hy *= 2;
      is_pressed = false;
      recount ();
      break;
    case Qt::Key_Space:
      draw_type++;
      draw_type %= 3;
      break;
//    case Qt::Key_Enter:
//      rhs_type++;
//      rhs_type %= 2;
//      recount ();
//      break;
    default:
      break;
    }
  updateGL ();
}

void MainWindow::drawFunction ()
{
  int i, j;
  double x1, x2, x3, x4;
  double y1, y2, y3, y4;
  double z1, z2, z3, z4;
  double curr_x, curr_y;

  glColor3d (255./ 255, 55. / 255, 105. / 255);
  for (i = 0; i < n; i++)
    {
      curr_x = x[1] - i * hx;
      curr_y = y[1] - i * hy;
      for (j = 0; j < i; j++)
        {
          x1 = curr_x + j * hx, y1 = curr_y, z1 = ff (x1, y1);
          x2 = curr_x + (j + 1) * hx, y2 = curr_y, z2 = ff(x2,y2);
          x3 = curr_x + (j - 1) * hx, y3 = curr_y - hy; z3 = ff(x3, y3);
          x4 = curr_x + j * hx, y4 = curr_y - hy, z4 = ff(x4, y4);

          glBegin (GL_TRIANGLES);
          glVertex3d (x1, y1, z1);
          glVertex3d (x2, y2, z2);
          glVertex3d (x4, y4, z4);


          glVertex3d (x1, y1, z1);
          glVertex3d (x3, y3, z3);
          glVertex3d (x4, y4, z4);
          glEnd ();
        }
      j = i;
      x1 = curr_x + j * hx, y1 = curr_y, z1 = ff (x1, y1);
      x2 = curr_x + (j - 1) * hx, y2 = curr_y - hy, z2 = ff(x2,y2);
      x3 = curr_x + (j + 0) * hx, y3 = curr_y - hy; z3 = ff(x3, y3);
      x4 = curr_x + (j + 1) * hx, y4 = curr_y - hy, z4 = ff(x4, y4);

      glBegin (GL_TRIANGLES);
      glVertex3d (x1, y1, z1);
      glVertex3d (x2, y2, z2);
      glVertex3d (x3, y3, z3);


      glVertex3d (x1, y1, z1);
      glVertex3d (x3, y3, z3);
      glVertex3d (x4, y4, z4);
      glEnd ();

      for (j = i + 1; j < 2 * i + 1; j++)
        {
          x1 = curr_x + (j - 1) * hx, y1 = curr_y, z1 = ff (x1, y1);
          x2 = curr_x + j * hx, y2 = curr_y, z2 = ff(x2,y2);
          x3 = curr_x + j * hx, y3 = curr_y - hy, z3 = ff(x3, y3);
          x4 = curr_x + (j + 1) * hx, y4 = curr_y - hy, z4 = ff (x4, y4);

          glBegin (GL_TRIANGLES);
          glVertex3d (x1, y1, z1);
          glVertex3d (x2, y2, z2);
          glVertex3d (x3, y3, z3);


          glVertex3d (x2, y2, z2);
          glVertex3d (x3, y3, z3);
          glVertex3d (x4, y4, z4);
          glEnd ();
        }
    }

  for (i = n; i > 0; i--)
    {
      curr_x = x[0] + (n - i) * hx;
      curr_y = y[0] - (n - i) * hy;
      for (j = 1; j < i; j++)
        {
          x1 = curr_x + (j - 1) * hx, y1 = curr_y, z1 = ff (x1, y1);
          x2 = curr_x + (j + 0) * hx, y2 = curr_y, z2 = ff(x2,y2);
          x3 = curr_x + (j + 0) * hx, y3 = curr_y - hy, z3 = ff(x3, y3);
          x4 = curr_x + (j + 1) * hx, y4 = curr_y - hy, z4 = ff(x4, y4);

          glBegin (GL_TRIANGLES);
          glVertex3d (x1, y1, z1);
          glVertex3d (x2, y2, z2);
          glVertex3d (x3, y3, z3);


          glVertex3d (x2, y2, z2);
          glVertex3d (x3, y3, z3);
          glVertex3d (x4, y4, z4);
          glEnd ();
        }
      j = i;
      x1 = curr_x + (j - 1) * hx, y1 = curr_y, z1 = ff (x1, y1);
      x2 = curr_x + (j + 0) * hx, y2 = curr_y, z2 = ff(x2,y2);
      x3 = curr_x + (j + 1) * hx, y3 = curr_y, z3 = ff(x3, y3);
      x4 = curr_x + (j + 0) * hx, y4 = curr_y - hy, z4 = ff(x4, y4);

      glBegin (GL_TRIANGLES);
      glVertex3d (x1, y1, z1);
      glVertex3d (x2, y2, z2);
      glVertex3d (x4, y4, z4);


      glVertex3d (x2, y2, z2);
      glVertex3d (x3, y3, z3);
      glVertex3d (x4, y4, z4);
      glEnd ();

      for (j = i + 1; j < 2 * i; j++)
        {
          x1 = curr_x + (j + 0) * hx, y1 = curr_y, z1 = ff (x1, y1);
          x2 = curr_x + (j + 1) * hx, y2 = curr_y, z2 = ff (x2, y2);
          x3 = curr_x + (j - 1) * hx, y3 = curr_y - hy, z3 = ff (x3, y3);
          x4 = curr_x + (j + 0) * hx, y4 = curr_y - hy, z4 = ff (x4, y4);

          glBegin (GL_TRIANGLES);
          glVertex3d (x1, y1, z1);
          glVertex3d (x3, y3, z3);
          glVertex3d (x4, y4, z4);


          glVertex3d (x1, y1, z1);
          glVertex3d (x2, y2, z2);
          glVertex3d (x4, y4, z4);
          glEnd ();
        }
    }
}
